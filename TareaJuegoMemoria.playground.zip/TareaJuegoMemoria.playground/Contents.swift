//Tarea 1: Minireto Juego de Memoria

import UIKit

var numeros = 0...100
var resultado:[String] = []

for numero in numeros{
    if numero % 5 == 0 {
        resultado.append("Bingo!!!")
    }
    
    if numero % 2 == 0{
        resultado.append("Par!!!")
    }
    
    if numero % 2 >= 1{
        resultado.append("Impar!!!")
    }
    //
    if numero >= 30 && numero <= 40{
        resultado.append("Viva Swift!!!")
    }
    
    print("#\(numero) \t\(resultado)")
    
    resultado.removeAll()
}
