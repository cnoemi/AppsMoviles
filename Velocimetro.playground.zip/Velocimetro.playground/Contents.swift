//: Velocimetro: Elementos para reprecentar el velocímetro de un automóvil

import UIKit

enum Velocidades : Int {
 
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50 , VelocidadAlta = 120

    init (velocidadInicial : Velocidades){
        self = velocidadInicial
    }

}

class Auto {

    var velocidad : Velocidades
    var estadoNumerico : Int
    
    init (estadoInicial : Velocidades) {
        self.velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
        self.estadoNumerico = estadoInicial.rawValue
    }
    
    func cambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String ){
        var velActual : Int?
        var cadena : String?

        if (self.estadoNumerico == 0) {
            velActual = self.estadoNumerico
            cadena = "\(self.velocidad)"
            self.estadoNumerico = 20
            self.velocidad = Velocidades.VelocidadBaja
        } else if (self.estadoNumerico == 20) {
            velActual = self.estadoNumerico
            cadena = "\(self.velocidad)"
            self.estadoNumerico = 50
            self.velocidad = Velocidades.VelocidadMedia
        } else if (self.estadoNumerico == 50) {
            velActual = self.estadoNumerico
            cadena = "\(self.velocidad)"
            self.estadoNumerico = 120
            self.velocidad = Velocidades.VelocidadAlta
        } else if (self.estadoNumerico == 120) {
            velActual = self.estadoNumerico
            cadena = "\(self.velocidad)"
            self.estadoNumerico = 50
            self.velocidad = Velocidades.VelocidadMedia
        }
        
        return (velActual!, cadena!)
    }
}


var velocidades = Velocidades.Apagado
velocidades.rawValue
var auto = Auto(estadoInicial: velocidades)
auto.velocidad


for i in 0...20 {
    print (auto.cambioDeVelocidad())
}
